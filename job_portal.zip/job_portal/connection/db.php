<?php
$c=mysqli_connect("localhost","root","","Database");
if(!$c){
    die(mysqli_connect_error($c));
}
?>
